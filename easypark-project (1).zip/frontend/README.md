Frontend README placeholder
