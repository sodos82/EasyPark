// Auth route placeholder
