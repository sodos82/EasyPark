// JWT auth middleware placeholder
